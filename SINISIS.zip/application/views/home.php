<html>
	<head>
		<title>
			Home APP
		</title>
	</head>
	<body>
		<p align="center"><h2 align="center">Halaman Home</h2></p>
		<p align="center"><a href="<?php echo base_url()?>Mahasiswa/home"> Masuk </a></p>
	</body>
</html>